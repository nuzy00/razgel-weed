local QBCore = exports['qb-core']:GetCoreObject()

CreateThread(function()
    while true do
        Wait(600000) -- 10 dakika = 600000 ms

        for _, playerId in pairs(QBCore.Functions.GetPlayers()) do
            local Player = QBCore.Functions.GetPlayer(playerId)
            if Player then
                Player.Functions.AddItem("weed", 50) --  Ot İtem 
                TriggerClientEvent('QBCore:Notify', playerId, "10 dakika geçti, 50 paketlenmiş ot aldın", "success")
            end
        end
    end
end)


RegisterNetEvent('razgel-weed:sellAmount', function(amount)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    local item = Player.Functions.GetItemByName("weed")

    if item and item.amount >= amount then
        Player.Functions.RemoveItem("weed", amount)
        local money = amount * Config.SellPrice
        Player.Functions.AddMoney("bank", money)
        TriggerClientEvent('QBCore:Notify', src, amount.." paket otu sattın, "..money.."$ kazandın", "success")
    else
        TriggerClientEvent('QBCore:Notify', src, "Yeterli paket yok", "error")
    end
end)