local QBCore = exports['qb-core']:GetCoreObject()
local selling = false


CreateThread(function()
    RequestModel(Config.NPC.model)
    while not HasModelLoaded(Config.NPC.model) do Wait(1) end
    local ped = CreatePed(4, Config.NPC.model, Config.NPC.coords.x, Config.NPC.coords.y, Config.NPC.coords.z - 1, Config.NPC.heading, false, true)
    FreezeEntityPosition(ped, true)
    SetEntityInvincible(ped, true)
    SetBlockingOfNonTemporaryEvents(ped, true)
end)


CreateThread(function()
    while true do
        Wait(0)
        local player = PlayerPedId()
        local coords = GetEntityCoords(player)
        local dist = #(coords - Config.NPC.coords)

        if dist < 2.0 then
            DrawText3D(Config.NPC.coords.x, Config.NPC.coords.y, Config.NPC.coords.z + 1.0, "[E] Ot Sat")
            if IsControlJustPressed(0, 38) and not selling then
                selling = true
                OpenSellMenu()
            end
        end
    end
end)

function OpenSellMenu()
    local Player = QBCore.Functions.GetPlayerData()
    local maxAmount = 0
    for k,v in pairs(Player.items) do
        if v.name == "packedweed" then -- Ot itemini gir
            maxAmount = v.amount
        end
    end

    if maxAmount == 0 then
        QBCore.Functions.Notify("Üzerinde paketlenmiş ot yok", "error")
        selling = false
        return
    end

    local amount = 1

    while selling do
        local input = exports['qb-input']:ShowInput({
            header = "Satmak istediğin paket miktarı",
            submitText = "Sat",
            inputs = {
                { type = 'number', isRequired = true, name = 'amount', text = 'Miktar (max '..maxAmount..')' }
            }
        })

        if input then
            amount = tonumber(input.amount)
            if amount and amount > 0 and amount <= maxAmount then
                local total = amount * Config.SellPrice
                QBCore.Functions.Notify("Toplam para: "..total.."$", "info")
                TriggerServerEvent('razgel-weed:sellAmount', amount)
                selling = false
                return
            else
                QBCore.Functions.Notify("Geçerli bir miktar gir", "error")
            end
        else
            selling = false
            return
        end
    end
end

function DrawText3D(x,y,z,text)
    SetTextScale(0.35, 0.35)
    SetTextFont(4)
    SetTextProportional(1)
    SetTextEntry("STRING")
    SetTextCentre(true)
    AddTextComponentString(text)
    SetDrawOrigin(x,y,z, 0)
    DrawText(0.0, 0.0)
    ClearDrawOrigin()
end