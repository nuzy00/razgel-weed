Config = {}

Config.WeedItem = "packed_weed" -- Satılacak İtem 
Config.SellPrice = 500 -- Satınca gelecek para

Config.NPC = { -- 
    coords = vector3(), --  Satım yapılacak npc 
    heading = 180.0,
    model = "g_m_y_mexgoon_02"
}